import java.util.*;
import java.io.*;

class AssassinGame {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(new File("C:\\Users\\krueg\\Documents\\Zoom\\player_names.txt"));
            ArrayList<String> names = new ArrayList<String>(); //Reads the text file and uses the add method to add the players
            while (sc.hasNext()) {
                names.add(sc.nextLine());
            }
            sc.close();

            Player[] players = new Player[names.size()];
            for (int i = 0; i < names.size(); i++) {   //stores all the players into a list
                players[i] = new Player(names.get(i));
            }
            KillRing killRing = new KillRing(players);
            Graveyard graveyard = new Graveyard();  //prints the graveyard and the kill ring

            Scanner input = new Scanner(System.in);
            while (killRing.head != killRing.head.next) {
                killRing.print();
                graveyard.print();   //prints the graveyard and the kill ring
                System.out.print("Enter the name of the next victim: ");
                String name = input.nextLine();
                Player victim = killRing.kill(name);            //scanner to input a name
                if (victim == null) {
                    System.out.println("That player is not in the kill ring.");  //if not a valid name
                } else {
                    System.out.println(victim.name + " has been killed!");  //if a sucessful name it prints the name and killed
                    graveyard.add(victim);  //adds player to the graveyard
                }
            }
            Player winner = killRing.head;
            System.out.println("The winner is " + winner.name + "!");  //if there's only one player in the kill list then shows winner
            graveyard.print();
            input.close();

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
    }
}

class Player {
    String name;
    Player next;   //defines a player

    Player(String name) {
        this.name = name;
        this.next = null;
    }
}

class KillRing {
    Player head;

    KillRing(Player[] players) {
        this.head = null;
        shuffle(players);
        for (Player player : players) {  //method to add players
            add(player);
        }
    }

    private void shuffle(Player[] players) {
        Random rand = new Random();
        for (int i = players.length - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);   //method to shuffle the players into a random order
            Player temp = players[i];
            players[i] = players[j];
            players[j] = temp;
        }
    }

    private void add(Player player) {
        if (head == null) {
            head = player;
            head.next = head;
        } else {
            Player temp = head;
            do {
                if (temp.next == head) {
                    temp.next = player;   //adds the players to the kill ring and sets the head
                    player.next = head;
                    return;
                }
                temp = temp.next;
            } while (temp != head);
        }
    }

    void print() {
        if (head == null) {
            System.out.println("Kill ring is empty!");
            return;
        }
        System.out.print("Kill ring: ");
        Player temp = head;
        do {
            if (temp == null) {
                break;
            }
            System.out.print(temp.name + " ");   //Method to print if the kill ring is empty or prints out the remaining people in the kill ring
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }

    Player kill(String name) {
        if (head == null) {
            return null;
        }
        Player temp = head;
        Player prev = null;
        do {
            if (temp != null && temp.name.equalsIgnoreCase(name)) {
                if (prev == null) {
                    head = head.next;
                    Player last = head;
                    while (last.next != temp) {             //kills the player selected in the list and if the player selected is the head moves the head
                        last = last.next;
                    }
                    last.next = head;
                } else {
                    prev.next = temp.next;
                }
                temp.next = null;
                return temp;
            }
            prev = temp;
            temp = temp.next;
        } while (temp != head);
        return null;
    }
}
class Graveyard {
    Player head;

    void add(Player player) {
        if (head == null) {
            head = player;
        } else {
            Player temp = head;
            while (temp.next != null) {         //method to add and store people that are killed in the kill ring
                temp = temp.next;
            }
            temp.next = player;
        }
    }

    void print() {
        if (head == null) {
            System.out.println("Graveyard is empty!");
            return;
        }
        Player temp = head;
        System.out.print("Graveyard: ");        //method to call to print the players in the graveyard for each iteration.
        while (temp != null) {
            System.out.print(temp.name + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

